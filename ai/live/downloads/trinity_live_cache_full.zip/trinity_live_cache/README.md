# TRINITY LIVE Cache Bundle

- Generated: `2026-07-01T16:52:48Z`
- Cache schema: `1.0`
- Source repo: `crangprang/TRINITY_LIVE` branch `main`
- Source head: `4d40a3dbd0b1dcd17cb8de4c8ce7c562e2a92152`
- Live documents: `244`
- Live chunks: `320`

## Use

- Use `source_repo/` for TRINITY_LIVE source files.
- Use `live_reader_pack/` for generated search, document JSON, and chunk JSON.
- TRINITY_LIVE is live canon. Treat source files as authoritative unless superseded by a later live export.
