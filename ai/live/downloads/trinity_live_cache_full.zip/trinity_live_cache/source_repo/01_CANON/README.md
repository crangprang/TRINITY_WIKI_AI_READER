# 01_CANON

`01_CANON` is the canon stabilizer for the repo.

## Live Contract

- Numbered `.txt` files are the live canon truth surface.
- `*_index.json` files are navigation only.
- Canon text is the source of truth; indexes help find it, but do not outrank it.
- `WC01_DETAILS_02_COMPOSITION.txt` is now split by category. Read the sibling `02A`-`02D` files for divine system, dragon/treasure tables, apparatus system, and phenomena/technique details.

## Reading Order

1. the numbered canon `.txt` files
2. the relevant index file only as a map

## Phase 2 Boundary

- Keep the current hierarchy and IDs.
- Do not flatten or rename the canon surface in this phase.
- Do not treat index files as reader-facing truth.
