# 02_LORE

`02_LORE` is the live lore surface.

## Live Contract

- Nation lore packages now live directly under `02_LORE/`.
- Until a lore unit is migrated, its current single live `.txt` file remains active.
- Migrated nation lore units use coded package directories such as `L06_TRUTH/`.
- Current migrated examples:
  - `L00_OLYMPIA/`
  - `L06_TRUTH/`
  - `L10_EREMOS/`
- Current package template:
  - `L##_CORE.txt`
  - `L##_FACT_DETAIL.txt`
  - `L##_BRANCH_IDEA.txt`
  - `L##_REFERENCE.txt`
- `L##_CORE.txt` keeps the shortest live core of the lore unit.
- `L##_FACT_DETAIL.txt` keeps stable detail at the same truth rank.
- Live lore prose stays near the `WC00_TIMELINE`~`WC01_DETAILS` band: direct expository blocks, concrete world nouns before abstract framing, and usually one to two short paragraphs per unit.
- `L##_BRANCH_IDEA.txt` keeps non-fact expansion and alternate-direction notes.
- `L##_REFERENCE.txt` keeps support anchors, recall prompts, and scene reference below truth.
- Lore packages do not create `VOICE_SAMPLE` equivalents.
- Root/package indexes remain navigation-only and may list both single live files and migrated package directories.
- Load-bearing apparatus-core truth belongs in package `L##_CORE.txt` / `L##_FACT_DETAIL.txt`: system identity, components, control, operation, fuel, side effects, failure signs, and stop-cost move there when they shape the country's live surface.
- Load-bearing proto-origin truth also belongs in package `L##_CORE.txt` / `L##_FACT_DETAIL.txt`: original role, corruption direction, and residual national habit move there when they shape the country's live surface.
- Named persona acting notes and counterpart pressure belong in `04_MAIN_CHARACTER`, not in the nation lore package.

## Read Order

1. `GOAL.txt`
2. matching `01_CANON`
3. target `CORE` and `FACT_DETAIL`, or current single live `.txt`
4. `BRANCH_IDEA`
5. `REFERENCE`
6. approved handoff or external archive input only when an actual path exists in the current environment
7. archive material only as candidate support after handoff review

## Current Boundary

- `02_LORE` is now nation-first at the root for migrated nation packages.
- Do not recreate `00_REGION/`, `01_NINE_NATION_APPARATUS/`, or `02_NINE_NATION_PROTO_PHILOSION/` as live surfaces.
- Keep apparatus / proto truth absorbed into the package unless it is clearly support-only.
