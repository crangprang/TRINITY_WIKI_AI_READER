# PART1_NINE_NATIONS_ERA

This part is the active plot scaffold for the Nine Nations era.

## Part Contract

- `CH` is the chapter layer.
- `EP` is the episode layer.
- `M` is the module layer.
- `S` is the scene layer.
- chapter files keep long-form movement readable
- episode files carry the concrete beats
- default and template files support episode writing, not replace it

## Active Shape

- `BUILDUP_EPI` covers the nine-nation buildup episodes
- `BRIDGE_EPI` covers bridge episodes between major beats
- `EREMOS_EPI` covers Eremos-specific work
- `OLYMPIA_EPI` covers Olympia-specific work
- `SINGULARITY EPISODE` files are chapter-level specials, not a separate canon system

## Guide Compression

- the root guide explains the global plot-and-scene role
- this part guide explains the active era and the chapter/episode contract
- chapter directories should stay focused on live chapter files, default files, and templates
- the old `README_AI.md` guidance has been absorbed here:
  - chapter files are the top-level narrative unit
  - episode files hold the actual module and scene structure
  - chapter-level indexes or status boards should only exist if they are truly needed for navigation

## Current Phase Note

- `PART1_NINE_NATIONS_ERA` is the active development area
- `PART2_GODS_ERA` and `PART3_OVERMANS_ERA` remain future placeholders
- keep future placeholders outside the active surface until they become real content
