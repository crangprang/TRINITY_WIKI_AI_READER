# 05_PLOT_AND_SCENE

`05_PLOT_AND_SCENE` is the live surface for plot order, episode flow, and scene beats.

It does not invent new setting truth. It arranges settled truth into readable narrative units.

## Current Contract

- `CHAPTER`: long progression unit
- `EPISODE`: readable beat unit
- `MODULE`: functional beat inside an episode
- `SCENE`: the concrete scene itself

## Reading Order

1. `GOAL.txt`
2. `AGENTS.md`
3. this root guide
4. the active part guide, such as `PART1_NINE_NATIONS_ERA/PART1_README.txt`
5. the live chapter, episode, and template files

## What Lives Here

- root guidance for plot and scene handling
- part-level guidance for the active era
- live chapter and episode files
- default and template surfaces used by chapter files

## What Does Not Live Here

- canon settlement
- lore settlement
- world settlement
- character settlement
- broad operating policy

Those are established elsewhere first, then arranged here.

## Current Phase Note

- `PART1_NINE_NATIONS_ERA` is the active development area.
- future parts stay as placeholders until they hold real live text.
- this folder should stay readable as a narrative scaffold, not a second canon system.
