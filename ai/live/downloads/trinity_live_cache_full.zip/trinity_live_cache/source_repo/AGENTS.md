# TRINITY_LIVE Agent Notes

This repo is live canon. Read as needed, but edit only when the user explicitly asks.

Keep only canon-facing material here. Drafts, review notes, generated outputs, experiments, backups, and unclear historical material belong under `../projects_archive/TRINITY_LIVE/` or workspace `RUN/TRINITY_LIVE/`.

When unsure whether something is canon, do not move or rewrite it.
