# 04_MAIN_CHARACTER

`04_MAIN_CHARACTER` is the live character surface.

## Live Contract

- rebuild characters into coded packages
- until a character is migrated, its current single `.txt` file remains live
- do not keep `_ORIGINAL`, `_V1`, `90_REFERENCE`, or section index files in the live tree as standing live surfaces
- narrow exception: if the user explicitly parks an `_ORIGINAL`-type source baseline during an active package rebuild to prevent compression or omission, keep it as temporary working support, not live truth, and preserve it conservatively until rebuild QA is done
- use `SEATID_SEQUENCE_NAME.txt` only when multiple historical successors of the same seat must remain live at once
- current seat-succession exception:
  - `AX06_01_PANDORA.txt`
  - `AX06_02_ELPIS.txt`
- current migrated package examples:
  - `00_PARTY/P01_EIN/`
  - `00_PARTY/P02_YEN/`
  - `00_PARTY/P03_GUILTIER/`
  - `00_PARTY/P04_JIN/`
  - `00_PARTY/P05_ELIZABETH/`
  - `00_PARTY/P06_SERENA/`
  - `00_PARTY/P07_DANTE/`
- current split-track exception:
  - `00_PARTY/P05_ELIZABETH/` keeps shared `P05_CORE.txt` at package root and splits track-local `CORE / FACT_DETAIL / BRANCH_IDEA / REFERENCE / VOICE_SAMPLE` into `P05_01_BLANC/` and `P05_02_SCARLETT/`
- current persona status:
  - `05_PERSONA/` packages are intentionally reduced to minimal identity/anchor cards until the next persona-wide development pass.
  - persona `VOICE_SAMPLE` files are placeholders for future voice work, not current live dialogue texture.
- current party package template:
  - file set:
    - `P01_CORE.txt`
    - `P01_FACT_DETAIL.txt`
    - `P01_BRANCH_IDEA.txt`
    - `P01_REFERENCE.txt`
    - `P01_VOICE_SAMPLE.txt`
- current persona package template:
  - file set:
    - `PER01_CORE.txt`
    - `PER01_FACT_DETAIL.txt`
    - `PER01_BRANCH_IDEA.txt`
    - `PER01_REFERENCE.txt`
    - `PER01_VOICE_SAMPLE.txt`
- `P##_CORE.txt` keeps the shortest live core of the character
- `P##_CORE.txt` is the new live package file name, distinct from legacy `00_CORE.txt` in the `legacy archive`
- `P##_FACT_DETAIL.txt` keeps stable detail and scene operation without canon conflict
- `P##_BRANCH_IDEA.txt` keeps non-fact expansion, variation, and alternate-direction notes for later promotion
- `P##_REFERENCE.txt` keeps character-only judgment, anchors, and scene reference below truth
- `P##_VOICE_SAMPLE.txt` keeps speech texture, honorifics, rhythm, and actual dialogue
- `PER##_` files carry the same roles for persona packages.
- non-image handoffs and working notes that are not live truth stay outside live
  canon under workspace `RUN/TRINITY_LIVE/`, `RUN/handoff/TRINITY_LIVE/`, or
  `../projects_archive/TRINITY_LIVE/`; image prompt packs, visual QA, prompt
  rules, generated pools, curated selections, and runtime archives stay in
  `IMAGE/` or `RUN/IMAGE/` through `prompt://...`, `visualqa://...`,
  `asset://pool/...`, and `asset://curated/...`
- when a character depends on apparatus / proto anchors, read the relevant `02_LORE` package `L##_CORE.txt` / `L##_FACT_DETAIL.txt` first and use `L##_REFERENCE.txt` only for support spillover; named persona behavior and counterpart-specific push should live here on the character side

## Read Order

1. `GOAL.txt`
2. matching `01_CANON` / `02_LORE` if the character depends on world-state confirmation
3. the target live character package `CORE` and `FACT_DETAIL`, or current single live file
4. `VOICE_SAMPLE` when phrasing or dialogue texture matters
5. `BRANCH_IDEA` when expansion paths are needed
6. `REFERENCE` when support anchors are needed
7. matching approved handoff support only when an actual external path is present
8. the `legacy archive` only as candidate support after handoff review

## Writing Rule

- for rebuilt characters, lock `source priority -> approval/rejection list -> merged working draft -> package split -> voice extraction -> process note`
- keep `VOICE` fully separate from canonical and fact/detail text
- keep content QA and prose QA as separate passes
- do not casually summarize or compact creative prose during package rebuild; if detail, rhythm, or sentence flavor may shift, preserve the fuller source and cut only after a loss check
- write `1.8` after the earlier character sections are grounded; it should summarize usable triggers and leakage points, not introduce new unsupported machinery
- keep relationship entries asymmetric when the character logic is asymmetric; do not flatten them into mutual comfort by default
- provenance and archive descent paths do not belong in the live file
- some files still carry legacy internal heading shapes; filename and live-surface status are already normalized, while internal structure can be refined in later passes

## Promotion Rule

- within `04_MAIN_CHARACTER`, approved handoff text is the promotion baseline unless it conflicts with `GOAL.txt`, `01_CANON`, or `02_LORE`
- the `legacy archive` is no longer peer truth; use it only to reinforce stable scene-usable material that handoff and canon do not contradict
- safe `OLD` pickups are gesture, voice texture, living habits, relation triggers, practical object use, and other scene-ready details
- `P##_BRANCH_IDEA.txt` is not fact, not canon, and not auto-promotable truth; it is a holding place for future extension paths
- do not silently import new chronology, new mechanics, new culture rules, or handoff-overwriting claims from `OLD`
- if a claim is strong but still unresolved, leave it in handoff or archive instead of half-promoting it into the live file
