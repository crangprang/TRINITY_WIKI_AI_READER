# 04_FELLSION

이 폴더의 `FS##_*.txt` 파일은 현재 live single-file surface다.

## Current State

- 파일명과 위치는 live로 유지한다.
- 내부 구조는 아직 party/persona package 형식으로 마이그레이션하지 않았다.
- 이번 정리는 구버전 명칭, Markdown 강조, 지칭/따옴표 오류 같은 즉시 혼선을 만드는 표면만 정리한 상태다.

## Use Rule

- `04_MAIN_CHARACTER/01_ENSEMBLE/E04_COLLAPSE_ERGO.txt`, `E05_BETRAYAL.txt`, `02_TRINEAD/TR04_DEATH.txt`, `TR05_VOID.txt`와 충돌하면 상위 live 파일을 우선한다.
- `붕괴`는 현재 canonical name route이며, 구버전 `소멸` 표기는 새 작업에 쓰지 않는다.
- package-level 재개발 전까지 이 파일들의 scene detail은 후보로 읽고, 새 mechanics나 chronology를 자동 확정하지 않는다.

