# 04_CREATURE

`04_CREATURE` is the country-based creature branch of `03_WORLD`.

## Live Surface

- Country creature packages use the same country order as `02_LORE`, but with `C00` to `C10`.
- Each country package has `01_NONSAPI/` for non-sapient life and `02_FANTASMA/` for phantasma.
- `00_WC_LIFE_CLASSIFICATION.txt` is the route map and operating rule for this branch.
- `99_NINE_DRAGONS` keeps the nine dragon phantasma dossiers together as the shared 4급 exception.

## Folder Contract

Each country package uses this structure:

- `01_NONSAPI/01_BEAST`
- `01_NONSAPI/02_PHERAD`
- `01_NONSAPI/03_SPIRIT`
- `01_NONSAPI/04_PROTIST`
- `02_FANTASMA/01_GRADE_1`
- `02_FANTASMA/02_GRADE_2`
- `02_FANTASMA/03_GRADE_3`

The nine dragon 4급 dossiers stay together in `99_NINE_DRAGONS` instead of being split into country packages.

## Reading Rule

- Read `00_WC_LIFE_CLASSIFICATION.txt` before adding or moving creature files.
- Read the matching country lore package under `02_LORE` before promoting a creature candidate.
- Treat named creature dossiers as live world truth.
- Treat empty folders as route scaffolds, not proof that a creature class has live content.

## Candidate Staging

- When a country has many creature candidates but individual dossiers are still thin, keep them in the relevant class-level `*_BRANCH_IDEA.txt` file instead of creating one file per creature too early.
- Class-level branch files may preserve candidate pools, local nicknames, ecological premises, and apply guards.
- Promote a candidate from a class-level branch file into its own dossier only after it has enough minimum detail: name, class, base organism or belief, habitat, behavior, field response, and seal/purification point when relevant.
